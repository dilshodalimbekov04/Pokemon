# Welcome to My Pokemon App
Dilshod Alimbekov

## Task
Create a ReactJS application. This will be a single route application. 

You can do all the normal operations: next, previos you can do 

these operations but my pokemon app doesn't have a search engine


## Description

My task is easy to understand and 

complex and created a component file inside a single src file
## Installation
```
npm install

npm start
```

## Usage
Dilshod Alimbekov
```
./my_project argument1 argument2
```

### The Core Team
<a href="https://github.com/dilshodalimbekov04">Pokemon</a>

<span><i>Made at <a href='https://qwasar.io'>Qwasar Silicon Valley</a></i></span>
<span><img alt='Qwasar Silicon Valley Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
